const API_KEY = "70c0f37d32418fd05d8d818df14f3238";

export { API_KEY };
