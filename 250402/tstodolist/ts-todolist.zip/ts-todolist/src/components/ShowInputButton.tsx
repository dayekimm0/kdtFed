import styled from "styled-components";
import Button from "./Button";

const Container = styled.div`
  position: absolute;
  right: 40px;
  bottom: 40px;
  z-index: 1;
`;

const ShowInputButton = () => {
  return (
    <Container>
      {" "}
      <Button
        label={showToDoInput ? "닫기" : "할 일 추가"}
        color={showToDoInput ? undefined : "#304ffe"}
        onClick={() => setShowToDoInput(!showToDoInput)}
      />
    </Container>
  );
};

export default ShowInputButton;
