import { useState } from "react";
import styled from "styled-components";
import GlobalStyles from "./styles/GlobalStyles.styles";
import DataView from "./components/DataView";
import ToDoInput from "./components/ToDoInput";
import ShowInputButton from "./components/ShowInputButton";

const Container = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const mockData = ["React 공부하기", "운동하기", "책읽기"];

function App() {
  const [toDoList, setToDoList] = useState(mockData);
  const [showToDoInput, setShowToDoInput] = useState(false);

  const onDelete = (todo: string) => {
    setToDoList(toDoList.filter((item) => item !== todo));
  };

  const onAdd = (todo: string) => {
    setToDoList([...toDoList, todo]);
    setShowToDoInput(false);
  };
  return (
    <>
      <GlobalStyles />
      <Container>
        <DataView toDoList={toDoList} onDelete={onDelete} />
        {showToDoInput && <ToDoInput onAdd={onAdd} />}
        <ShowInputButton />
      </Container>
    </>
  );
}

export default App;
